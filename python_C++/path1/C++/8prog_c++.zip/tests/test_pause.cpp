#include <iostream>

int main()
{
    
    system("pause");
}
