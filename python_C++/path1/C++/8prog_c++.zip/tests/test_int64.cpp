#include <iostream>

int main()
{
    int64_t x;
}
