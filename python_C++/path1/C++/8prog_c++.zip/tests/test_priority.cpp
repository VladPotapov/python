#include <iostream>
using namespace std;
int main()
{
  int i = 10;
  cout << !(i+2);
  cout << (!i)+2;
  cout << !i+2;
  cin.get();
}
